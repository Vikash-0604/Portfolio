var typed = new Typed(".text", {
    strings: ["Full Stack Developer"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})

var typed = new Typed(".text1", {
    strings: ["Me"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})
var typed = new Typed(".text2", {
    strings: ["Services"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})
var typed = new Typed(".text3", {
    strings: ["Skills"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})
var typed = new Typed(".text4", {
    strings: ["Projects"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})

var typed = new Typed(".text5", {
    strings: ["Me"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})
